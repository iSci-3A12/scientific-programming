function [stats] = simple_stats(numbers_in)
% simple_stats.m 
%
% This function takes a column vector (n rows x 1 column) as input and
% creates a column vector output (as the variable 'stats'). 
% The function should ignore NaNs (i.e. not cause the stats to be NaN if
% one exists in the list). 
% The output variable stats should be a 5 x 1 column vector with the
% following values: 
% - row 1: minimum value (excluding NaNs)
% - row 2: maximum value (excluding NaNs)
% - row 3: mean value (excluding NaNs)
% - row 4: median value (excluding NaNs)
% - row 5: highest prime number (if exists) or NaN if there are no prime numbers in numbers_in
% 
% usage: <TO DO> Fill this in <TO DO>
%
% Created by: <TO DO> Fill this in <TO DO>
% For you to do: 
% - Write the code for this function that creates the desired output. 
% - Complete the 'usage' and 'created by' information in the top comment section
% - Add comments in the function that explains what each section does.

stats = [NaN; NaN; NaN; NaN; NaN]; % Creates a placeholder for the output variable 'stats'
disp(numbers_in); % displays the inputted numbers in the command window 


