%%% process_adelaide.m
% This script ....<fill in this part with details about what the script does>
%
%
%
% Created by: 
%
% Date created: 
% 
%

%%%%% Your tasks with this function:
%%% 1. Complete the code where tasks have been left for you (indicated by <**TO DO**>)
%%% 2. Ensure that the script runs without issue and produces the figures in the \Figs directory
%%% 3. Comment the top and other edited lines appropriately.
%%%%%

%% Preparation
clearvars;
%%% Set a variable equal to the station name -- this way, we can reuse it to
% load and save things. 
station_name = 'Adelaide Airport'; 

%%% Colormap (used for barcode plots)
cmap = ([0,0,0.562500000000000;0,0,0.625000000000000;0,0,0.687500000000000;0,0,0.750000000000000;0,0,0.812500000000000;0,0,0.875000000000000;0,0,0.937500000000000;0,0,1;0,0.0625000000000000,1;0,0.125000000000000,1;0,0.187500000000000,1;0,0.250000000000000,1;0,0.312500000000000,1;0,0.375000000000000,1;0,0.437500000000000,1;0,0.500000000000000,1;0,0.562500000000000,1;0,0.625000000000000,1;0,0.687500000000000,1;0,0.750000000000000,1;0,0.812500000000000,1;0,0.875000000000000,1;0,0.937500000000000,1;0,1,1;0.117647059261799,0.992647051811218,0.992647051811218;0.235294118523598,0.985294103622437,0.985294103622437;0.352941185235977,0.977941155433655,0.977941155433655;0.470588237047195,0.970588207244873,0.970588207244873;0.588235318660736,0.963235318660736,0.963235318660736;0.705882370471954,0.955882370471954,0.955882370471954;0.823529422283173,0.948529422283173,0.948529422283173;0.941176474094391,0.941176474094391,0.941176474094391;0.948529422283173,0.948529422283173,0.823529422283173;0.955882370471954,0.955882370471954,0.705882370471954;0.963235318660736,0.963235318660736,0.588235318660736;0.970588207244873,0.970588207244873,0.470588237047195;0.977941155433655,0.977941155433655,0.352941185235977;0.985294103622437,0.985294103622437,0.235294118523598;0.992647051811218,0.992647051811218,0.117647059261799;1,1,0;1,0.937500000000000,0;1,0.875000000000000,0;1,0.812500000000000,0;1,0.750000000000000,0;1,0.687500000000000,0;1,0.625000000000000,0;1,0.562500000000000,0;1,0.500000000000000,0;1,0.437500000000000,0;1,0.375000000000000,0;1,0.312500000000000,0;1,0.250000000000000,0;1,0.187500000000000,0;1,0.125000000000000,0;1,0.0625000000000000,0;1,0,0;0.937500000000000,0,0;0.875000000000000,0,0;0.812500000000000,0,0;0.750000000000000,0,0;0.687500000000000,0,0;0.625000000000000,0,0;0.562500000000000,0,0;0.500000000000000,0,0]);
%%% Create a cell array with column names for the input file 
colheaders = {'Year','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'}; % Column headers

%%% Load the data for the site from the /Data directory:
stn_data = readmatrix(['Data/' station_name '.csv']); % Note how we've built the filename from the station name.
%%% <**TO DO**> Open up the data in the Variable Browser and inspect. 

%%% Pull out years and temperatures from stn_data
years = stn_data(:,1); % Pull out column of years from stn_data (first column)
temps = stn_data(:,2:end); % Pull out matrix of temperatures from stn_data (all rows x the last 12 columns)
temps(temps==-9999)= NaN; % Turn -9999s into NaNs
temps = temps./100; % Turn temperatures into degrees Celsius. 
clear stn_data; % Clear this variable because we'll use 'years' and 'temps' from now on

%%% Create some labels to use for plotting
first_ten_mult = find(mod(years,10)==0,1,'first'); % Find the first year in the time series that is evenly divisible by 10. 
year_labels = num2str(years([first_ten_mult:20:numel(years)])); % We'll create a set of labels that start at the first_ten_mult and advance by 20.

%%%%%%%%%%%%%%%%%%%%
%% Calculate annual means, anomalies
ref_start = 1951;
ref_end = 1980;

%%% Calculate annual means so that years with an NaN in any month will also have NaNs in annual average 
% <**TO DO**> Figure out how to take the mean of all years (i.e. average temperatures for each row across columns <TO DO> 
annual_mean = ; % <**TO DO**> hint: enter 'doc mean' into the command window to learn how to average across columns

% Mean of reference period -- take average of all non-NaNs between the reference years
annual_mean_ref = mean(annual_mean(years>=ref_start & years<= ref_end & ~isnan(annual_mean)));

%%% <**TO DO**> Calculate Annual anomalies by subtracting annual_mean_ref from annual_mean and <TO DO>
anoms_annual = ; % <**TO DO**> 

%%%%%%%%%%%%%%%%%%%%%%
%% Calculate trendline *** THIS IS DONE FOR YOU *** 
ind = find(~isnan(anoms_annual)); % find years without an NaN
%%% fit a first-order (linear) polynomial
p = polyfit(years(ind),anoms_annual(ind),1); % p(1) is the slope, p(2) is the intercept
anoms_annual_trend = polyval(p,years); % polyval uses the linear coefficients to create predicted values (i.e. our trendline)

%%%%%%%%%%%%%%%%%%%%%%
%% Figure 1: Create line plot and save it to the /Figs directory with a filename that matches the station name *** 
%%% Plot (this part is done)
fig1 = figure; clf;
plot(years,anoms_annual,'b.-'); hold on; % Plot the anomaly time series
plot(years,anoms_annual_trend,'r-'); % Plot the trend line
%%% <**TO DO**> Annotate and style the figure. YOU NEED TO FINISH THIS <**TO DO**> 
ylabel(''); 
xlabel('');
legend('','');
print('-dpng',['Figs\' station_name '_timeseries']); % saves as .png with the name of the station in the filename. See how handy it is to reuse variables?

%%%%%%%%%%%%%%%%%%%%%
%% Figure 2: Create a 'Barcode' graph of Annual anomalies and save it to the /Figs directory with a filename that matches the station name *** YOU NEED TO FINISH THIS *** 
%%% Rearrange and plot (This is done for you)
anoms_annual_plot = anoms_annual'; % transpose for plotting purposes
anoms_annual_plot(isnan(anoms_annual_plot))=0;
fig2 = figure;
imagesc(anoms_annual_plot);
shading flat;
colormap(cmap); % Sets a colormap using the cmap array we created at the beginning of the script.
caxis([-2 2]); % Scales the limits of the colours to +/- 2 degrees C
c2 = colorbar; 
set(gca,'XTick',[first_ten_mult:20:numel(years)]);
set(gca,'XTickLabels',year_labels);
set(gca,'YTick',[]); % Leave this blank-it removes ticks on the y-axis.
%%% <TO DO> Save this in the Figs\ directory (as above) with the name of the station and '_barcode' (i.e. '\Figs\Adelaide Airport_barcode') <TO DO>
ylabel(c2,''); % <**TO DO**> GIVE THE COLORBAR A LABEL -- What is it communicating? 
print('-dpng',[]); % <**TO DO**> HINT: copy from the print command in the last figure and change '_timeseries'   









