%% iSci_Intermediate.m
% This script will lead you through some more advanced MATLAB operations
% and commands:

%%% The Scenario:
% You've been given this 'lucky number generating program' from a friend.
% You suspect that it's outputting nothing but uniformly random numbers
% between 1 and 100. How can you investigate this?

%% 1. Loops:
% Often, you may find that you need to repeat a process many times.
% Instead of doing these manually, you can use a loop to do the work for
% you.
% Here, we will use a loop to run your lucky number estimator many times.
% We will save the results from each run.

name = 'Jimmy'; % character array (string) 

% Most commonly, we use the 'for' command, which allows us to specify how
% many times we want the loop to run.  We enter all operations we want
% repeated beneath the 'for' statement, and then close it up with 'end'
% e.g. Run your function 100 times:


for i = 1:1:100 
    lucky_numbers = my_lucky_numbers(name);
end
% Here, we've made a for loop that runs from 1, increasing by 1, to 100
% i is a counter variable, that will increase by 1 with every loop (it
% keeps track of what loop we're on so we can use it as a variable, if we wish).

% Let's change the input name:
name = 'YourName'; % Change this to your name 

% Look at lucky_numbers (the output variable).  
% Q: How big is the matrix you just made? How big did you expect it to be?
% A: Looking at the variable in your Workspace, you'll see that
% lucky_numbers is 1x6 (1 row by 6 columns).

% Explanation: The problem here is that we keep overwriting the data to the same row, so
% the output is always 1x6. 
% Instead, we can use the value of i to write the numbers to a new row each time we run it:
clear lucky_numbers; % clear the existing variable from the Workspace
for i = 1:1:100
    lucky_numbers(i,:) = my_lucky_numbers(name);
end

% Q: What is the size of lucky_numbers now?  
% A: lucky_numbers should now be 100x6. 

%%% NOTE: Loops can count up or down at any interval, and the counting
%%% variable can have any name. This will be demonstrated below

%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 2. If statements
% An 'if' statement evaluates whether or not the value of a variable matches a specified condition. 
% If it the statemnt is found to be true (the variable matches the condition), it will execute whatever commands are below it.  
% If it is untrue, it will execute the commands that are below an 'else' statement. 
% Having an 'else' statement is optional.
% Just like 'for' loops, 'if' statements have to be closed with an 'end'

% Here's a loop that counts up by 7, with an if statement inside of it:
for looploop = 3:7:90
    if isprime(looploop)==1
        disp([num2str(looploop) ' is a prime number.']); %num2str is a function that converts a number to a character
    else
    end
end
% Q: What does the 'if' statement do here?
% A: (for you to figure out)
%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 3. Indexing and the 'find' function
% The 'find' function tells you the location(s) in matrices where specified
% conditions exist.  For example, we can use find on our lucky numbers to
% learn more about them. 

% First, rearrange the 100x6 matrix to a single column using (:) 
lucky_numbers = lucky_numbers(:); % using (:) puts everything into 1 column

% Let's try and use the 'find' function to figure out if the lucky numbers
% are somewhat evenly distributed between 1 and 100:
over70 = find(lucky_numbers > 70); % over70 is a list of the row numbers in lucky numbers where the value is >70
over_eq50 = find(lucky_numbers >= 50); % same, but for >=50
equals100 = find(lucky_numbers == 100); % rows where lucky_numbers is exactly 100
under10 = find(lucky_numbers < 10); % all rows where luck_numbers is less than 10

% Look at the size of each of these variables in your Workspace. 
% Q: How do the sizes of variabels match your expectations? 
% Q: Can you come to any conclusions about the 'randomness' of these values, or is it unclear at this point? 
% A: If these are randomly-produced numbers, we'd expect the sizes of each variable to fall into a range. 
% A: We can't really tell at this point if the values we see are well
% outside the expected values to the point that it's statistically significant
%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 4. Saving and Loading:
% There are many different ways to save your data, depending on what format
% you want to save your data in.  The functions to do this include:
% - 'save': used to save data to a matlab-specific (.mat) file (not readable in excel)
% - 'xlswrite': saves data in .xls format
% - 'writematrix': saves data as plain text in a comma separated format (.csv). Readable by most programs.
%
% Similarly, there are corresponding functions for loading
% e.g. 'load', 'readmatrix', 'xlsread', etc.

% Let's save our lucky numbers in .csv format to the Data/ directory:
% To figure out how to do this go to help:
doc writematrix

% Write the contents of the variable lucky_numbers to the file /Data/lucky_numbers.csv:
cd('/MATLAB Drive/iSci3A12-SciProgramming') % Run this to make sure you're in the correct directory;
writematrix(lucky_numbers,['Data/lucky_numbers.csv']);

% Using the Current Folder browser, ensure that lucky_numbers.csv exists in the /Data folder. 
% - If it doesn't exist--repeat parts 3 and 4 above 
% - If it exists, double-click it to open a preview. It should be a 600x1 matrix.

% Once you've confirmed that lucky_numbers.csv is saved properly, clear all the existing variables in the workspace:
clearvars;

% Now, load the contents of lucky_numbers.csv as a variable named luck_num
% using the function 'readmatrix'
% Note that we can assign whatever name we want to a variable when we load
% it back in. We'll use luck_num for the rest of the analyses:
doc readmatrix;
luck_num = readmatrix(['Data/lucky_numbers.csv']);
%%%%%%%%%%%%%%%%%%%%%
%% 5. Plotting:

%%% 5.1. Line Plots, and simple properties:
% To create a plot (or to bring up one that exists, we use the 
% 'figure' command
figure(1) % This creates a blank figure (if figure 1 doesn't exist), or brings it back up (if it already has been made)

% There are many different plot types we can make.  The simplest is a line
% plot (or time series plot).  We use the 'plot' command for this:
plot(luck_num);

% By default, you get a line plot in blue, with no title or legend. Let's
% change some of these features:
%%% Line Type: 
plot(luck_num,'.');  % Plots data points as dots instead of connected series
plot(luck_num,'.-'); % Connected dots
plot(luck_num,'--'); % Dashed line
plot(luck_num,'o'); % Open Circles
plot(luck_num,'s-'); % Connected Open Squares

%%% Color:
plot(luck_num,'r.-'); % Makes the line and dots red.
plot(luck_num,'gp-'); % Green.
plot(luck_num,'kx'); % Makes the 'x's red.
plot(luck_num,'.','Color',[0.8 0.4 0.5]); % Can specify color as [Red Green Blue] from 0 to 1

%%% Marker and Line Colors
plot(luck_num,'s-','Color',[0.2 0.3 0.7],'MarkerEdgeColor',[1 0.1 0.1],'MarkerFaceColor',[0.4 0.7 0.2],'LineWidth',3 ); % Makes the line and dots red.

%%% Holding content on a figure
% Notice that each time you plot, you lose the previously plotted data.
% If you want to keep the previous plotted data, use the command:
hold on;
% Now, we can plot a second series on top of it:

%%% Exercise:
% Let's use the 'randi' function to create 5 different sets of 
% 600 random numbers between 1 and 100:
doc randi; % execute this to learn more about the 'randi' function
rand_num = randi([1,100],600,5); 
% Q: What are the dimensions of your new rand_num variable? 
% A: rand_num should be 600x5 

% Plot these 5 sets of numbers on top of our existing plot: 
plot(rand_num,'c.-'); % Plots a random series of 600 numbers between 1 and 100

%%% Clearing a figure:  
% Use the command 'clf' to clear the figure:
clf; 
plot(luck_num,'r.-'); % Makes the line and dots red.
hold on;
plot(rand_num(:,1),'c.-'); % Plots the first random series of 600 numbers between 1 and 100

%%% Adding a Legend:
% The 'legend' command adds a legend to the plot. The labels correspond to
% the order of plotted series in your figure.
legend('lucky numbers','random numbers');
% You can specify the location of the legend on the figure by using the
% 'Location' keyword, and then specifying a compass direction:
legend('lucky numbers','random numbers','Location','NorthWest');

%%% Title, X and Y labels,  Font Size
% Set the title using the title command:
title('Lucky and Random Numbers','FontSize',14);
% 'FontSize' sets the weight of the font.

% Set the x- and y-labels with the following Commands:
xlabel('Sample Number','FontSize',14);
ylabel('Number Value','FontSize',14);

% Set the font size of the axes and the legend with:
set(gca,'FontSize',14); % The 'gca' stands for 'get current axes'

% Let's replot this, with all the commands together, as figure 2:
figure(2);clf;
plot(luck_num,'r.-'); % Makes the line and dots red.
hold on;
plot(rand_num(:,1),'cx-'); % Plots a random series of 600 numbers between 1 and 100
legend('lucky numbers','random numbers','Location','NorthWest');
title('Lucky and Random Numbers','FontSize',14);
xlabel('Sample Number','FontSize',14);
ylabel('Number Value','FontSize',14);
set(gca,'FontSize',14);

%%%% Questions: %%%%%
% Q: Does figure 2 tell us much about whether or not the 'lucky numbers'
% are, in fact, random?  Why or why not?  What is there an apparent 
% trend in the data?
% A: It doesn't tell us much, unfortunately. There is a
% definitive trend in the lucky numbers from our program (that doesn't seem
% to exist in the random numbers). 
%
% Q2: How did this trend get there? 
% A2: If you recall, we collapsed 6 columns of our lucky numbers into one. 
% When we did this, we stacked the columns below each other. 
% As a result the first 100 values came from column 1 (i.e. the smallest
% numbers of each set of lucky numbers); the next 100 from column 2 (i.e. the second
% smallest numbers of each set); etc. This causes our results to be sorted
% to a certain extent. 
% We'll need to explore further. 
%%%%%%%%%%%%%%%%%
%% 6. Sorting Values

%%% Sorting 
% Let's try sorting both sets of numbers from lowest to largest value
% using the 'sort' command. We'll then plot them on top of each other:
luck_num_sort = sort(luck_num); % sorting luck_num from smallest to largest
rand_num_sort = sort(rand_num); % sorting rand_num from smallest to largest

%%% Figure Handles
% Another way specify a figure is to assign it a variable name (you can
% then recall this figure by referring to its variable name)
f2b = figure(); 
figure(f2b); clf;
% Plot our sorted lucky numbers: 
plot(luck_num_sort,'r.-','LineWidth',2); % Makes the line and dots red.
hold on;
% Let's plot all the random number series on top of our lucky numbers.  
% Since we're not specifying a column to plot, MATLAB assumes that we want
% to plot each column as a separate line.  It will give each its own color
plot(rand_num_sort,'LineWidth',0.5);
legend('LuckyNumbers','Random1','Random2','Random3','Random4','Random5','Location','NorthWest')
title('Lucky and Random Numbers','FontSize',14);
xlabel('Sample Number','FontSize',14);
ylabel('Number Value','FontSize',14);
set(gca,'FontSize',14);
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 7. Printing Figures:

% Figures can be saved by either using the 'Save' option in the
% tool panel (with the figure selected), or by using the MATLAB function 'print'
% Note that this will print whichever figure is currently active (last
% selected).  
% Let's save our last figure to the /Figs/ directory
% We can make sure we save the right one by calling figure 2
% again:
cd('/MATLAB Drive/iSci3A12-SciProgramming') % Run this to make sure you're in the correct directory;
figure(f2b)
print('-dpng',['Figs/lucky_random_numbers']); % saves as .png
print('-dtiff',['Figs/lucky_random_numbers']); % saves as .tiff
print('-djpeg',['Figs/lucky_random_numbers']); % saves as .jpg
% See 
doc print % for more information about printing figures

% Confirm that these figures now exist in your /Figs directory

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 7.1 Other Types of plots.
% There are many types of plots. Highlight either variable in Workspace,
% and click the dropdown 'plot' menu above to see the different types of
% plots available.

%%% Closing figures:
% You can close a figure by using the 'close' command:
close(f2b);

%%% Scatterplot:
% Can be done similar to a line plot, except that you specify both x and y
% values:
figure(3);
plot(rand_num(:,1),luck_num,'b.'); % Scatterplot between random (x) and lucky numbers (y)
title('Random vs. Lucky Numbers','FontSize',14);
xlabel('Random Numbers','FontSize',14);
ylabel('Lucky Numbers','FontSize',14);
set(gca,'FontSize',14);

%%% Bar Graphs:
% The command 'bar' is used to make a bar graph, and the command 'histc'
% creates a histogram bar graph.
% Let's make and compare histograms of the distribution of numbers in 
% rand_num and luck_num to see if they are similar (use the 'histc'
% command')
doc histc;
edges = (0:5:100)';
% Do for Lucky Numbers:
counts_lucky = histc(luck_num,edges);
fbar_lucky = figure();
bar(edges+2.5,counts_lucky);
title('Histogram for Lucky Numbers','FontSize',14);
xlabel('Value of Lucky Number','FontSize',14);
ylabel('Count','FontSize',14);

% Do for Random Numbers:
counts_rand = histc(rand_num,edges);
fbar_rand = figure();
bar(edges+2.5,counts_rand);
title('Histogram for Random Numbers','FontSize',14);
xlabel('Value of Random Number','FontSize',14);
ylabel('Count','FontSize',14);

%%% Closing figures:
% You can close a figure by using the 'close' command:
close(figure(fbar_rand));
% Or, close all:
close all;

%%%% Questions: %%%%%
% Q: Do these figures hint at anything amiss with our lucky numbers? 
% Do there appear to be any discrepancies between our lucky numbers and the
% randomly-generated ones? What might cause this? 
% HINT: Take a close look at the number of values between 20 and 30. 
%%%%%%%%%%%%%%%%%%%%%%%
%% 8. Statistical Tests
% Let's try and solve this by means of a statistical test

% First, let's define our null hypthesis:
% H0: There is no statistical difference between the distribution of our lucky numebers and those randomly generate. 
% %% In other words: Our lucky numbers are randomly sampled from a population with a uniform distribution.

% We can use the two-sample kolmogorov-smirnov test to evaluate whether
% our sample data (lucky numbers) differ significantly from what we'd
% expect if the numbers were uniformly randomly selected:
doc kstest2

% Generate 50000 random numbers from a uniform distribution, 1 to 100.
rand_num = randi([1,100],50000,1);
name = 'Kanye';

% Use my_lucky_numbers.m function to generate a larger sample of data than before:
for i = 1:1:1000
    lucky_numbers(i,:) = my_lucky_numbers(name);
end
% Compare with our lucky numbers using the ks-test
[h,p] = kstest2(lucky_numbers(:),rand_num);

% Note the values of 'h' and 'p' in the Workspace or use the 'disp' function to print them onto the screen  
disp(['Value of p = ' num2str(p) '; Value of h = ' num2str(h)]); % we need to convert the numeric values to characters using 'num2str'
% View the documentation for kstest2 to interpret the results:
doc kstest2

%% 9. FINAL ANALYSES
% Q: Given the evidence from the figures and statistical test, is the lucky number generator outputting completely random values?
% Q2: If no, what might be causing this non-randomness? 
%%% HINT: view 'my_lucky_numbers' again and scroll around the entirety of
%%% the script to see if any code has been hidden anywhere. :)